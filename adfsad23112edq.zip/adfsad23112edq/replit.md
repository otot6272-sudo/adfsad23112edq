# Spotify Metadata Discord Bot

## Overview
A Discord bot that fetches and displays detailed metadata for Spotify tracks. The bot responds to commands with track information including artists, album, label, ISRC codes, and distribution details.

## Project Architecture
- **Language**: Python 3.12
- **Main Dependencies**: discord.py, requests
- **APIs Used**: 
  - Spotify Web API (for all track and album metadata)
- **Bot Framework**: discord.py with command framework

## Features
- Parse Spotify track URLs/URIs from multiple formats
- Fetch comprehensive track metadata from Spotify API
- Extract ISRC license information from album copyright data
- Parse distributor information from Spotify copyright text
- Display information in rich Discord embeds with album artwork
- Built-in test suite for core functionality

## Recent Changes (2025-09-29)
- ✅ Imported project from GitHub
- ✅ Moved files from subdirectory to root
- ✅ Installed Python 3.12 via Replit modules
- ✅ Synced dependencies with uv (discord.py, requests, and all required packages)
- ✅ Created .gitignore for Python project
- ✅ Configured Discord Bot workflow for console output
- ✅ Verified bot code is properly configured to use environment variables
- ✅ Removed third-party API dependencies (MusicBrainz, Musicfetch)
- ✅ Implemented Spotify-only metadata extraction using album copyright parsing
- ✅ Added ISRC License and Distributor extraction from copyright text

## Configuration Required
The bot requires three environment variables to be set in Replit Secrets:

1. **DISCORD_TOKEN**: Your Discord bot token from the Discord Developer Portal
2. **SPOTIFY_CLIENT_ID**: Your Spotify app client ID
3. **SPOTIFY_CLIENT_SECRET**: Your Spotify app client secret

### How to Get These Credentials:

**Discord Token:**
1. Go to https://discord.com/developers/applications
2. Create a new application or select existing one
3. Go to "Bot" section
4. Copy the token

**Spotify Credentials:**
1. Go to https://developer.spotify.com/dashboard
2. Create a new app or select existing one
3. Copy the Client ID and Client Secret

## Usage
Once configured with proper secrets, the bot supports:
- `!track <spotify-url>` - Get detailed metadata for a Spotify track

The bot displays the following information:
- Track name and artists
- Album and label
- ISRC code and license holder
- UPC code
- Distributor (parsed from copyright text)

## Current State
- ✅ Dependencies installed
- ✅ Security issues fixed
- ✅ Workflow configured
- ⚠️ Requires environment variables to be set before bot can run
- ⚠️ Some type hints need refinement for better LSP support

## Commands
- `python spotify_metadata_bot.py` - Run the Discord bot
- `python spotify_metadata_bot.py test` - Run the test suite