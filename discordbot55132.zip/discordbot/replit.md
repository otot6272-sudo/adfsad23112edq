# Spotify Metadata Discord Bot

## Overview
A Discord bot that fetches and displays detailed metadata for Spotify tracks. The bot responds to commands with track information including artists, album, label, ISRC codes, and distribution details.

## Project Architecture
- **Language**: Python 3.12
- **Main Dependencies**: discord.py, requests
- **APIs Used**: 
  - Spotify Web API (for track metadata)
  - MusicBrainz API (for additional label/distributor info)
- **Bot Framework**: discord.py with command framework

## Features
- Parse Spotify track URLs/URIs from multiple formats
- Fetch comprehensive track metadata from Spotify API
- Enhance metadata with MusicBrainz data when available
- Display information in rich Discord embeds with album artwork
- Built-in test suite for core functionality

## Recent Changes (2025-09-28)
- Fixed security vulnerability by removing hardcoded tokens from source code
- Configured proper environment variable usage for secrets
- Set up Python virtual environment with uv package manager
- Created Discord Bot workflow for console output
- Installed required dependencies: discord.py, requests

## Configuration Required
The bot requires three environment variables to be set in Replit Secrets:

1. **DISCORD_TOKEN**: Your Discord bot token from the Discord Developer Portal
2. **SPOTIFY_CLIENT_ID**: Your Spotify app client ID
3. **SPOTIFY_CLIENT_SECRET**: Your Spotify app client secret

### How to Get These Credentials:

**Discord Token:**
1. Go to https://discord.com/developers/applications
2. Create a new application or select existing one
3. Go to "Bot" section
4. Copy the token

**Spotify Credentials:**
1. Go to https://developer.spotify.com/dashboard
2. Create a new app or select existing one
3. Copy the Client ID and Client Secret

## Usage
Once configured with proper secrets, the bot supports:
- `!track <spotify-url>` - Get detailed metadata for a Spotify track

## Current State
- ✅ Dependencies installed
- ✅ Security issues fixed
- ✅ Workflow configured
- ⚠️ Requires environment variables to be set before bot can run
- ⚠️ Some type hints need refinement for better LSP support

## Commands
- `python spotify_metadata_bot.py` - Run the Discord bot
- `python spotify_metadata_bot.py test` - Run the test suite