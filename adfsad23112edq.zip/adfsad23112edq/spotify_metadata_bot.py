"""
Spotify Metadata Bot — asyncio-safe (fixed _start_discord_bot_safely)

This file starts the Discord bot in a way that avoids `asyncio.run()` being
called while another event loop is already running (common in notebooks).

Fix summary:
- If an event loop is already running, schedule `bot.start(token)` with
  `loop.create_task(...)` so we don't call `asyncio.run()`.
- If no loop is running, create a fresh event loop and call
  `loop.run_until_complete(bot.start(token))` instead of `bot.run()` to avoid
  `asyncio.run()` under the hood.
- Added a small keyboard-interrupt shutdown path to try to cleanly stop the bot
  when running in a new loop.

Everything else (Spotify token flow, MusicBrainz lookup, tests) is preserved.
"""

from __future__ import annotations

import base64
import logging
import os
import re
import sys
import asyncio
from typing import Dict, Optional

import requests

# Optional imports (discord). If discord isn't installed, the bot part will not run,
# but tests that don't need discord can still run.
try:
    import discord  # type: ignore
    from discord.ext import commands  # type: ignore
except Exception:  # pragma: no cover - discord may not be available in test env
    discord = None
    commands = None


# ----------------------
# Configuration
# ----------------------
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID") 
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")

# Discord embed color for Spotify-like green
SPOTIFY_GREEN = 0x1DB954

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("spotify_metadata_bot")


# ----------------------
# Utilities
# ----------------------
def parse_spotify_track_id(url_or_uri: str) -> str:
    """Extract spotify track id from many possible URL forms.

    Examples:
      - https://open.spotify.com/track/{id}
      - https://open.spotify.com/track/{id}?si=xxx
      - spotify:track:{id}

    Raises ValueError if a track id cannot be extracted.
    """
    if not url_or_uri or not isinstance(url_or_uri, str):
        raise ValueError("Empty or invalid URL/URI")

    # spotify:track:ID
    m = re.match(r"spotify:track:([A-Za-z0-9]+)", url_or_uri)
    if m:
        return m.group(1)

    # https://open.spotify.com/track/ID and query params
    m = re.search(r"/track/([A-Za-z0-9]+)", url_or_uri)
    if m:
        return m.group(1)

    # fallback: a plain id
    m = re.match(r"^[A-Za-z0-9]+$", url_or_uri)
    if m:
        return url_or_uri

    raise ValueError(f"Could not parse Spotify track id from '{url_or_uri}'")


def get_spotify_access_token(client_id: str, client_secret: str) -> str:
    """Obtain a client-credentials access token from Spotify.

    Raises RuntimeError on failure.
    """
    if not client_id or client_id.startswith("YOUR_") or not client_secret or client_secret.startswith("YOUR_"):
        raise RuntimeError("Spotify credentials are not configured. Set SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET.")

    token_url = "https://accounts.spotify.com/api/token"
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    headers = {
        "Authorization": f"Basic {auth_header}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {"grant_type": "client_credentials"}

    resp = requests.post(token_url, data=data, headers=headers, timeout=10)
    if resp.status_code != 200:
        logger.error("Spotify token fetch failed: %s %s", resp.status_code, resp.text)
        raise RuntimeError(f"Failed to get Spotify token: {resp.status_code} {resp.text}")

    j = resp.json()
    return j.get("access_token")


def fetch_spotify_track(track_id: str, access_token: str) -> Dict:
    """Fetch track JSON from Spotify Web API.

    Raises RuntimeError on HTTP errors.
    """
    url = f"https://api.spotify.com/v1/tracks/{track_id}"
    headers = {"Authorization": f"Bearer {access_token}"}
    resp = requests.get(url, headers=headers, timeout=10)
    if resp.status_code != 200:
        logger.error("Spotify track fetch failed: %s %s", resp.status_code, resp.text)
        raise RuntimeError(f"Failed to fetch track: {resp.status_code} {resp.text}")
    return resp.json()


def fetch_spotify_album(album_id: str, access_token: str) -> Dict:
    """Fetch full album JSON from Spotify Web API including copyrights and UPC.

    Raises RuntimeError on HTTP errors.
    """
    url = f"https://api.spotify.com/v1/albums/{album_id}"
    headers = {"Authorization": f"Bearer {access_token}"}
    resp = requests.get(url, headers=headers, timeout=10)
    if resp.status_code != 200:
        logger.error("Spotify album fetch failed: %s %s", resp.status_code, resp.text)
        raise RuntimeError(f"Failed to fetch album: {resp.status_code} {resp.text}")
    return resp.json()


def clean_company_name(name: str) -> str:
    """Clean up company name by removing extra whitespace and quotes."""
    if not name:
        return ""
    return name.strip().strip('"').strip("'").strip()


def parse_copyright_for_licensee(copyrights: list) -> Optional[str]:
    """Parse copyright text for license holder/licensee.
    
    First tries 'under (exclusive) license to', then extracts company from P-line.
    Returns clean company name.
    """
    if not copyrights:
        return None
    
    for copyright_entry in copyrights:
        if copyright_entry.get("type") == "P":
            text = copyright_entry.get("text", "")
            
            # First try: "under (exclusive) license to Company"
            match = re.search(r'under (?:exclusive )?license to\s+([^,;\.]+)', text, re.IGNORECASE)
            if match:
                return clean_company_name(match.group(1))
            
            # Second try: Extract company after ℗/P and year
            match = re.search(r'(?:℗|\(P\)|P)\s*(?:\d{4})?\s*([^,;\.]+)', text, re.IGNORECASE)
            if match:
                return clean_company_name(match.group(1))
    
    return None


def parse_copyright_for_distributor(copyrights: list) -> Optional[str]:
    """Parse copyright text for distributor/marketer.
    
    Looks for distribution and marketing phrases.
    Returns clean distributor name.
    """
    if not copyrights:
        return None
    
    for copyright_entry in copyrights:
        text = copyright_entry.get("text", "")
        
        # Try multiple patterns in order of specificity
        patterns = [
            r'marketed\s*(?:and|&)\s*distributed by\s+([^,;\.]+)',
            r'manufactured\s*(?:and|&)\s*distributed by\s+([^,;\.]+)',
            r'distributed by\s+([^,;\.]+)',
            r'marketed by\s+([^,;\.]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return clean_company_name(match.group(1))
    
    return None


def get_copyright_holder(copyrights: list, copyright_type: str = "P") -> Optional[str]:
    """Extract the copyright holder from copyrights array.
    
    Args:
        copyrights: List of copyright entries from Spotify album data
        copyright_type: 'P' for phonographic (sound recording) or 'C' for composition
    
    Returns the copyright text if found, otherwise None.
    """
    if not copyrights:
        return None
    
    for copyright_entry in copyrights:
        if copyright_entry.get("type") == copyright_type:
            return copyright_entry.get("text", "")
    
    return None




def get_spotify_track_info(url_or_uri: str, spotify_client_id: str, spotify_client_secret: str) -> Dict[str, str]:
    """Get comprehensive track metadata using only Spotify Web API.

    Fields returned (strings):
      - Track, Artists, Album, Label, ISRC, ISRC License, UPC, Distributor
    """
    track_id = parse_spotify_track_id(url_or_uri)

    token = get_spotify_access_token(spotify_client_id, spotify_client_secret)
    track_json = fetch_spotify_track(track_id, token)

    album_simple = track_json.get("album", {})
    album_id = album_simple.get("id")
    
    # Fetch full album data to get copyrights and UPC
    album_json = fetch_spotify_album(album_id, token) if album_id else {}

    # Extract basic fields
    isrc = track_json.get("external_ids", {}).get("isrc") or "N/A"
    upc = (album_json.get("external_ids") or {}).get("upc") or "N/A"
    label = album_json.get("label", "N/A")
    copyrights = album_json.get("copyrights", [])

    # Parse copyright information for license and distributor
    licensee = parse_copyright_for_licensee(copyrights)
    distributor = parse_copyright_for_distributor(copyrights)

    # Build ISRC License field - use licensee or label, no full text fallback
    isrc_license = "N/A"
    if licensee:
        isrc_license = licensee
    elif label and label != "N/A":
        isrc_license = label

    # Build Distributor field - only use parsed distributor
    distributor_display = "N/A"
    if distributor:
        distributor_display = distributor

    data = {
        "Track": track_json.get("name", "N/A"),
        "Artists": ", ".join([a.get("name", "") for a in track_json.get("artists", []) if a.get("name")]) or "N/A",
        "Album": album_simple.get("name", "N/A"),
        "Label": label,
        "ISRC": isrc,
        "ISRC License": isrc_license,
        "UPC": upc,
        "Distributor": distributor_display,
    }
    return data


# ----------------------
# Discord bot (optional)
# ----------------------
if discord is not None and commands is not None:
    intents = discord.Intents.default()
    intents.message_content = True  # Enable message content intent
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info("✅ Logged in as %s", bot.user)

    @bot.command(name="track")
    async def cmd_track(ctx, *, url: Optional[str] = None):
        """Usage: !track <spotify-track-url-or-uri>"""
        try:
            if not url:
                await ctx.send("❌ **Error:** Please provide a Spotify track URL!\n**Usage:** `!track <spotify-url>`")
                return
                
            async with ctx.typing():
                if not SPOTIFY_CLIENT_ID or not SPOTIFY_CLIENT_SECRET:
                    await ctx.send("❌ Error: Spotify credentials not configured")
                    return
                info = get_spotify_track_info(url, SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET)

            embed = discord.Embed(
                title="🎵 Spotify Track Metadata",
                description=f"Here’s what I found for the track:",
                color=SPOTIFY_GREEN,
            )
            # Try to add album art if available
            try:
                if SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET:
                    token = get_spotify_access_token(SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET)
                    track_id = parse_spotify_track_id(url)
                    track_json = fetch_spotify_track(track_id, token)
                    album_images = (track_json.get("album", {}).get("images") or [])
                    if album_images:
                        embed.set_thumbnail(url=album_images[0].get("url"))
                    else:
                        embed.set_thumbnail(url="https://storage.googleapis.com/pr-newsroom-wp/1/2023/05/Spotify-Logo.png")
                else:
                    embed.set_thumbnail(url="https://storage.googleapis.com/pr-newsroom-wp/1/2023/05/Spotify-Logo.png")
            except Exception:
                embed.set_thumbnail(url="https://storage.googleapis.com/pr-newsroom-wp/1/2023/05/Spotify-Logo.png")

            for k, v in info.items():
                embed.add_field(name=k, value=v, inline=False)

            embed.set_footer(text="Allrii made this bot | Metadata from Spotify API")
            await ctx.send(embed=embed)

        except Exception as e:
            logger.exception("Failed to handle !track command: %s", e)
            await ctx.send(f"❌ Error: {e}")


def _start_discord_bot_safely(token: str) -> None:
    """Start the discord bot in a way that avoids nested asyncio.run() calls.

    - If there is a running event loop, schedule the bot as a background task
      using `loop.create_task(bot.start(token))`.
    - Otherwise, create a fresh event loop and run `bot.start(token)` with
      `loop.run_until_complete(...)` (this avoids asyncio.run internally).
    """
    if discord is None or commands is None:
        raise RuntimeError("discord.py not available; cannot start bot.")

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    # Check if bot is available before proceeding
    if 'bot' not in globals():
        raise RuntimeError("Bot is not defined. Discord.py may not be available.")
    
    bot_instance = globals()['bot']
    if bot_instance is None:
        raise RuntimeError("Bot is not defined. Discord.py may not be available.")
        
    if loop and loop.is_running():
        # Running inside an existing event loop (e.g., Jupyter). Schedule the bot.
        try:
            loop.create_task(bot_instance.start(token))
            logger.info("Bot scheduled as a background task in the existing event loop.")
        except Exception as e:
            logger.exception("Failed to schedule bot.start as a task: %s", e)
            raise
    else:
        # No running loop: create a new loop and run the bot there without using asyncio.run()
        new_loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(new_loop)
            new_loop.run_until_complete(bot_instance.start(token))
        except KeyboardInterrupt:
            # Attempt a graceful shutdown when interrupted
            logger.info("KeyboardInterrupt received: stopping bot")
            try:
                new_loop.run_until_complete(bot_instance.close())
            except Exception:
                pass
        finally:
            try:
                new_loop.run_until_complete(new_loop.shutdown_asyncgens())
            except Exception:
                pass
            new_loop.close()


# ----------------------
# Simple test suite
# ----------------------
import unittest


class TestSpotifyMetadataBot(unittest.TestCase):
    def test_parse_spotify_track_id_urls(self):
        cases = {
            "https://open.spotify.com/track/6rqhFgbbKwnb9MLmUQDhG6": "6rqhFgbbKwnb9MLmUQDhG6",
            "https://open.spotify.com/track/6rqhFgbbKwnb9MLmUQDhG6?si=abc": "6rqhFgbbKwnb9MLmUQDhG6",
            "spotify:track:6rqhFgbbKwnb9MLmUQDhG6": "6rqhFgbbKwnb9MLmUQDhG6",
            "6rqhFgbbKwnb9MLmUQDhG6": "6rqhFgbbKwnb9MLmUQDhG6",
        }
        for inp, expected in cases.items():
            self.assertEqual(parse_spotify_track_id(inp), expected)

    def test_parse_spotify_track_id_invalid(self):
        with self.assertRaises(ValueError):
            parse_spotify_track_id("")
        with self.assertRaises(ValueError):
            parse_spotify_track_id("https://open.spotify.com/album/6rqhFgbbKwnb9MLmUQDhG6")

    def test_build_info_keys(self):
        # This test ensures get_spotify_track_info returns all expected keys.
        fake_info = {
            "Track": "Fake Track",
            "Artists": "Some Artist",
            "Album": "Fake Album",
            "Label": "Fake Label",
            "ISRC": "N/A",
            "ISRC License": "N/A",
            "UPC": "N/A",
            "Distributor": "N/A",
        }
        # When discord isn't available, building an embed is not possible; instead we assert keys exist.
        self.assertSetEqual(set(fake_info.keys()),
                            {"Track", "Artists", "Album", "Label", "ISRC", "ISRC License", "UPC", "Distributor"})

    def test_spotify_credentials_missing_raises(self):
        # Deterministic test: calling token fetch with placeholder creds should raise.
        with self.assertRaises(RuntimeError):
            get_spotify_access_token("YOUR_SPOTIFY_CLIENT_ID", "YOUR_SPOTIFY_CLIENT_SECRET")

    @unittest.skipUnless(os.getenv("SPOTIFY_CLIENT_ID") and os.getenv("SPOTIFY_CLIENT_SECRET"), "Integration test requires Spotify credentials in env")
    def test_integration_fetch_track(self):
        # This test will actually call Spotify API. It's skipped unless credentials are provided.
        client_id = os.getenv("SPOTIFY_CLIENT_ID")
        client_secret = os.getenv("SPOTIFY_CLIENT_SECRET")
        if not client_id or not client_secret:
            self.skipTest("Spotify credentials not available")
        token = get_spotify_access_token(client_id, client_secret)
        self.assertIsInstance(token, str)
        info = get_spotify_track_info("https://open.spotify.com/track/3n3Ppam7vgaVa1iaRUc9Lp", client_id, client_secret)
        # basic sanity checks
        self.assertIn("Track", info)
        self.assertIn("ISRC", info)


def run_tests():
    loader = unittest.TestLoader()
    tests = loader.loadTestsFromTestCase(TestSpotifyMetadataBot)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(tests)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        sys.exit(run_tests())

    # Run the discord bot if discord is installed
    if discord is None or commands is None:
        logger.error("discord.py is not installed. Install it to run the bot, or run tests with 'python <file> test'.")
        sys.exit(1)

    if not DISCORD_TOKEN:
        logger.error("Please configure DISCORD_TOKEN in environment before running the bot.")
        sys.exit(1)

    logger.info("Starting Discord bot...")
    try:
        _start_discord_bot_safely(DISCORD_TOKEN)
    except Exception as e:
        logger.exception("Failed to start bot: %s", e)
        sys.exit(1)
